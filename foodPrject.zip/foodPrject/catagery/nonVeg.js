import { fetchFood } from "../utilities/index.js";
fetchFood("non-veg")