import { fetchFood} from "../utilities/index.js";

fetchFood("veg")